package com.example.vksdkkotlin.providers

import com.example.vksdkkotlin.presenters.FrendsPresentor

class FrendsProvider(var presentor: FrendsPresentor) {
    fun testLoadFrends(){
        
    }
}