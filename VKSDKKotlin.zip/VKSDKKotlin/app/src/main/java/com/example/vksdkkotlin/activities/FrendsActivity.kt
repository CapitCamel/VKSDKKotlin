package com.example.vksdkkotlin.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.vksdkkotlin.R

class FrendsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frends)
    }
}
