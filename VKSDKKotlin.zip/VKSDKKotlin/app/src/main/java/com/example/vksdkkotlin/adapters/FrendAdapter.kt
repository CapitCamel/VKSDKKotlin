package com.example.vksdkkotlin.adapters

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.vksdkkotlin.R
import com.example.vksdkkotlin.models.FrendModel

class FrendAdapter: RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    var mFrendList:ArrayList<FrendModel> = ArrayList()

    override fun getItemCount(): Int {
        return mFrendList.count()
    }

    override fun onBindViewHolder(p0: RecyclerView.ViewHolder, p1: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemView = layoutInflater.inflate(R.layout.cell_friend, parent, false)
        return FrendsViewHolder(itemView = itemView)
    }

    class FrendsViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){

    }

}