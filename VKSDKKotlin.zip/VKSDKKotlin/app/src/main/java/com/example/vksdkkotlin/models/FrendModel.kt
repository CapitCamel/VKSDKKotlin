package com.example.vksdkkotlin.models

class FrendModel(
    private var name: String,
    private var surname: String,
    private var city: String?,
    private var avatar: String?,
    private var isOnline: Boolean
) {

}