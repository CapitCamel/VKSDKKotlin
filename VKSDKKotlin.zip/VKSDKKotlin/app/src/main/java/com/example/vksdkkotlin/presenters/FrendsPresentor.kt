package com.example.vksdkkotlin.presenters

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.example.vksdkkotlin.views.FrendsView

@InjectViewState
class FrendsPresentor: MvpPresenter<FrendsView>() {
}